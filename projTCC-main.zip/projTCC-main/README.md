# projTCC
Projeto para o TCC em Django

## comandos
---console
python -m django startproject projTCC
cd./projTCC/
python manage.py startapp appsite
python manage.py makeimigrations
python manage.py migrate
python manage.py createsuperuser